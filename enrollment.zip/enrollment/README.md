## About Project
This project for enrollment with enrollee and dependent
	
## Commands to Compile & Build
To run this project,
```
$ mvn clean install
$ mvn spring-boot:run
```
## Domain classes
1) Enrollee
2) Dependent

## DB 
H2 IN-MEMORY

## End Uris and corresponding Request & Response

GET : http://localhost:8080/enrollee/all

POST: http://localhost:8080/enrollee/create

{
"name" :"Keerthi",
"activation" : "true",
"dob" : "1-1-1985",
"phoneNum" : "123-456-0000"
}

PUT: http://localhost:8080/enrollee/update

{
"id" : "1",
"name" :"Keerthi Reddy",
"activation" : "true",
"dob" : "1-1-1984",
"phoneNum" : "123-456-7890"
}

GET : http://localhost:8080/enrollee/1

DELETE : http://localhost:8080/enrollee/1

GET: http://localhost:8080/dependent/1/dependents


POST: http://localhost:8080/dependent/1
{
"name" :"Aneesh",
"dateOfBirth" : "1-1-2011"
}

{
	"name": "Kiran",
	"dateOfBirth": "1-1-2015"
}

PUT: http://localhost:8080/dependent/1
{
"id" : "1",
"name" :"Surya",
"dob" : "1-1-2014"

}

GET: http://localhost:8080/dependent/1

DELETE : http://localhost:8080/dependent/1/2

