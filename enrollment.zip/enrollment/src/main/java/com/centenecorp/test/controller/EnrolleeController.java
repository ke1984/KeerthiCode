package com.centenecorp.test.controller;

import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.centenecorp.test.domain.Enrollee;
import com.centenecorp.test.service.EnrolleeService;

@RestController
@RequestMapping("/enrollee")
public class EnrolleeController {
	private final Logger logger = LoggerFactory.getLogger(DepedentController.class);
	
	@Autowired
	EnrolleeService enrolleeService;
	
	/**
	 * End point for Get all enrollees
	 * @return List<Enrollee>
	 */
	@GetMapping("all")
    public List<Enrollee> getEnrollees() {
		logger.info("Started getEnrollees ");
    	return enrolleeService.getEnrollees();
    }
	
	/**
	 * End Point for Get Enrollee based Id
	 * @param id
	 * @return Enrollee
	 */
	@GetMapping("/{id}")
    public ResponseEntity<Enrollee> getEnrollee(@PathVariable("id") Long id) {
		Optional<Enrollee> enrollee = enrolleeService.getEnrolleeById(id);
        if(enrollee.isPresent()) {
        	logger.info("Enrolle Details : " , enrollee.get());
        }        
        return new ResponseEntity<Enrollee>(enrollee.get(), HttpStatus.OK);
	}
	
	/**
	 * End Point for Create Enrollee
	 * @param enrollee
	 * @return
	 */
	@PostMapping("create")
    public ResponseEntity<Enrollee> createEnrollee(@RequestBody Enrollee enrollee) {
        return new ResponseEntity<Enrollee>(enrolleeService.createEnrollee(enrollee), HttpStatus.CREATED);
    }
	
	/**
	 * End point for update enrollee
	 * @param enrollee
	 * @return
	 */
	@PutMapping("update")
    public ResponseEntity<Enrollee> updateEnrollee(@RequestBody Enrollee enrollee) {
		if(Objects.isNull(enrollee.getId())){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
        return new ResponseEntity<Enrollee>(enrolleeService.updateEnrollee(enrollee), HttpStatus.OK);
    }
	
	/**
	 * End point for delete enrollee
	 * @param id
	 */
	@DeleteMapping("{id}")
	public void deleteEnrollee(@PathVariable("id") Long id) {
		 enrolleeService.deleteEnrollee(id);
	}
	

}
