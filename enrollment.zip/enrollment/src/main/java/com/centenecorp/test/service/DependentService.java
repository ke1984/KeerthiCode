package com.centenecorp.test.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centenecorp.test.commons.RecordNotFoundException;
import com.centenecorp.test.domain.Dependent;
import com.centenecorp.test.domain.Enrollee;
import com.centenecorp.test.repository.DependentRepository;

@Service
public class DependentService {
	private final Logger logger = LoggerFactory.getLogger(DependentService.class);
	
	@Autowired
	DependentRepository dependentRepository;
	
	/**\
	 * 
	 * @param dependentId
	 * @return
	 */
	public Optional<Dependent> getDependent(Long dependentId) {
		Optional<Dependent> dependent = dependentRepository.findById(dependentId);
        if(!dependent.isPresent()) {
        	throw new RecordNotFoundException("Dependent Record not Found");
        }
        
        return dependent;
	}
	
	/**
	 * 
	 * @param enrollee
	 * @param dependent
	 * @return
	 */
	public Dependent createDependent(Enrollee enrollee, Dependent dependent) {
		dependent.setEnrollee(enrollee);		
		return dependentRepository.save(dependent);
	}
	
	/**
	 * 
	 * @param dependent
	 * @return
	 */
	public Dependent updateDependent(Dependent dependent) {
		Optional<Dependent> existdependent = dependentRepository.findById(dependent.getId());
        if(!existdependent.isPresent()) {
        	throw new RecordNotFoundException("Dependent Record not Found");
        }
        existdependent.get().setDob(dependent.getDob());
        existdependent.get().setName(dependent.getName());
		return dependentRepository.save(existdependent.get());
	}

	/**
	 * O
	 * @param dependentId
	 */
	public void deleteDependent(Long dependentId) {
		Optional<Dependent> dependent = dependentRepository.findById(dependentId);
    	if(!dependent.isPresent()) {
    		throw new RecordNotFoundException("Dependent Record not Found");
    	}
    	dependentRepository.deleteById(dependentId);
	}


}
