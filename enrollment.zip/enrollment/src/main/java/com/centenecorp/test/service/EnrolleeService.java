package com.centenecorp.test.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.centenecorp.test.commons.RecordNotFoundException;
import com.centenecorp.test.domain.Dependent;
import com.centenecorp.test.domain.Enrollee;
import com.centenecorp.test.repository.EnrolleeRepository;

@Service
public class EnrolleeService {
	private final Logger logger = LoggerFactory.getLogger(EnrolleeService.class);
	
	@Autowired
	EnrolleeRepository enrolleeRepository;
	
	/**
	 * 
	 * @return List<Enrollee>
	 */
	public List<Enrollee> getEnrollees(){
		List<Enrollee> enrolleeList = new ArrayList<>();
    	Iterable<Enrollee> enrollees= enrolleeRepository.findAll();
    	enrollees.forEach(enrolleeList::add);
    	
    	return enrolleeList;
	}
	
	/**
	 * 
	 * @param id
	 * @return Enrollee
	 */
	public Optional<Enrollee> getEnrolleeById(Long id){
		Optional<Enrollee> enrollee = enrolleeRepository.findById(id);
		if(!enrollee.isPresent()) {
        	throw new RecordNotFoundException("Enrollee Record not Found");
        }
		return enrollee;
	}
	
	/**
	 * 
	 * @param enrollee
	 * @return Enrollee
	 */
	public Enrollee createEnrollee(Enrollee enrollee){
		return enrolleeRepository.save(enrollee);
	}
	
	/**
	 * 
	 * @param enrollee
	 * @return
	 */
	public Enrollee updateEnrollee(Enrollee enrollee){
		Optional<Enrollee> record = enrolleeRepository.findById(enrollee.getId());
		if(!record.isPresent()) {
        	throw new RecordNotFoundException("Enrollee Record not Found");
        }
		Enrollee existedRecord = record.get();
		existedRecord.setName(enrollee.getName());
		existedRecord.setDob(enrollee.getDob());
		existedRecord.setActivation(enrollee.isActivation());
		existedRecord.setPhoneNum(enrollee.getPhoneNum());

		return enrolleeRepository.save(existedRecord);
	}
	
	/**
	 * Delete enrollee details
	 * @param id
	 */
	public void deleteEnrollee(Long id){
		enrolleeRepository.deleteById(id);
	}
	
	/**
	 * 
	 * @param id
	 * @return List<Dependent>
	 */
	public List<Dependent> getDependentsByEnrolleeId(Long id){
		Optional<Enrollee> enrollee = enrolleeRepository.findById(id);
		if(!enrollee.isPresent()) {
        	throw new RecordNotFoundException("Enrollee Record not Found");
        }
		return enrollee.get().getDependents();
	}

}
