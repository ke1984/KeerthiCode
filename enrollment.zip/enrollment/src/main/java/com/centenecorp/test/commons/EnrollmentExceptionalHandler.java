package com.centenecorp.test.commons;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class EnrollmentExceptionalHandler extends ResponseEntityExceptionHandler {
	
	@ExceptionHandler(RecordNotFoundException.class)
	public final ResponseEntity<Response> handleUserNotFoundException(RecordNotFoundException ex,
			WebRequest request) {
		Response exceptionResponse = new Response(ex.getMessage());
		return new ResponseEntity<Response>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
	
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<Response> handleAllExceptions(Exception ex, WebRequest request) {
		Response exceptionResponse = new Response(ex.getMessage());
		return new ResponseEntity<Response>(exceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
