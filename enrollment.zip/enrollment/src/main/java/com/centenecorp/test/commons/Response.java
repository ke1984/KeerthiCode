package com.centenecorp.test.commons;

public class Response {

	private String message;

	public Response(String message) {
		super();
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

}
